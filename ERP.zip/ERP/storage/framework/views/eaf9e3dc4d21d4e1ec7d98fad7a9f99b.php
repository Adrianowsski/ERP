<?php $__env->startSection('title','Invoices'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4 d-flex align-items-center">
        <i data-feather="file-text" class="me-2"></i> Invoices
    </h1>

    
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-3">
        <form method="GET" class="d-flex gap-2 align-items-center">
            <input
                name="q"
                class="form-control rounded-pill px-3"
                placeholder="Search by Number or Client..."
                value="<?php echo e(request('q')); ?>"
                style="min-width: 200px;"
            >
            <button class="btn btn-outline-dark rounded-pill d-inline-flex align-items-center px-3">
                <i data-feather="search" class="me-1"></i> Search
            </button>
        </form>

        <a href="<?php echo e(route('invoices.create')); ?>"
           class="btn btn-primary rounded-pill d-inline-flex align-items-center px-4 py-2">
            <i data-feather="plus" class="me-1"></i> Add Invoice
        </a>
    </div>

    
    <div class="d-flex flex-column flex-md-row justify-content-start align-items-start align-items-md-center gap-2 mb-4">
        <form method="GET" class="d-flex gap-2 align-items-center">
            <select
                name="sort"
                class="form-select rounded-pill"
                style="min-width: 180px;"
            >
                <option value="">Sort by</option>
                <option value="issue_asc"   <?php if(request('sort')==='issue_asc'): echo 'selected'; endif; ?>>Issue Date ↑</option>
                <option value="issue_desc"  <?php if(request('sort')==='issue_desc'): echo 'selected'; endif; ?>>Issue Date ↓</option>
                <option value="due_asc"     <?php if(request('sort')==='due_asc'): echo 'selected'; endif; ?>>Due Date ↑</option>
                <option value="due_desc"    <?php if(request('sort')==='due_desc'): echo 'selected'; endif; ?>>Due Date ↓</option>
            </select>
            <button class="btn btn-outline-dark rounded-pill d-inline-flex align-items-center px-3">
                <i data-feather="sliders" class="me-1"></i> Sort
            </button>
        </form>
    </div>

    
    <div class="table-responsive shadow-sm rounded">
        <table class="table table-bordered align-middle mb-0 bg-white">
            <thead class="table-light">
            <tr>
                <th style="width: 5%">#</th>
                <th style="width: 8%">Invoice No.</th>
                <th style="width: 15%">Issue Date</th>
                <th style="width: 15%">Due Date</th>
                <th style="width: 12%">Total</th>
                <th style="width: 35%">Client</th>
                <th class="text-end" style="width: 180px;">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration + ($invoices->currentPage() - 1) * $invoices->perPage()); ?></td>
                    <td><?php echo e($invoice->invoice_number); ?></td>
                    <td><?php echo e($invoice->issue_date->format('Y-m-d')); ?></td>
                    <td><?php echo e($invoice->due_date->format('Y-m-d')); ?></td>
                    <td><?php echo e(number_format($invoice->total, 2)); ?></td>
                    <td><?php echo e($invoice->order->client->name); ?></td>

                    
                    <td class="text-end d-flex flex-row justify-content-end flex-nowrap">
                        <a href="<?php echo e(route('invoices.show', $invoice)); ?>"
                           class="btn btn-sm btn-light border d-inline-flex align-items-center me-1"
                           title="View">
                            <i data-feather="eye" class="text-primary"></i>
                        </a>
                        <a href="<?php echo e(route('invoices.edit', $invoice)); ?>"
                           class="btn btn-sm btn-light border d-inline-flex align-items-center me-1"
                           title="Edit">
                            <i data-feather="edit-2" class="text-warning"></i>
                        </a>
                        <a href="<?php echo e(route('invoices.pdf', $invoice)); ?>"
                           class="btn btn-sm btn-light border d-inline-flex align-items-center me-1"
                           title="Download PDF">
                            <i data-feather="download" class="text-success"></i>
                        </a>
                        <form method="POST" action="<?php echo e(route('invoices.destroy', $invoice)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-light border d-inline-flex align-items-center"
                                    onclick="return confirm('Delete this invoice?')"
                                    title="Delete">
                                <i data-feather="trash-2" class="text-danger"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted">No invoices found.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-3">
        <?php echo e($invoices->withQueryString()->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\elpartner\resources\views/invoices/index.blade.php ENDPATH**/ ?>