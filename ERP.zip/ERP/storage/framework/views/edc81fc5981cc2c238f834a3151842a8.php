<?php $__env->startSection('title','Client Details'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4"><i data-feather="info" class="me-1"></i>Client Details</h1>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <dl class="row">
                <dt class="col-sm-4">Name</dt>
                <dd class="col-sm-8"><?php echo e($client->name); ?></dd>

                <dt class="col-sm-4">NIP</dt>
                <dd class="col-sm-8"><?php echo e($client->nip); ?></dd>

                <dt class="col-sm-4">Email</dt>
                <dd class="col-sm-8"><?php echo e($client->email); ?></dd>

                <dt class="col-sm-4">Phone</dt>
                <dd class="col-sm-8"><?php echo e($client->phone); ?></dd>

                <dt class="col-sm-4">Address</dt>
                <dd class="col-sm-8"><?php echo e($client->address); ?></dd>
            </dl>
            <div class="d-flex justify-content-between">
                <a href="<?php echo e(route('clients.edit', $client)); ?>" class="btn btn-warning"><i data-feather="edit" class="me-1"></i>Edit</a>
                <a href="<?php echo e(route('clients.index')); ?>" class="btn btn-secondary"><i data-feather="arrow-left" class="me-1"></i>Back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\elpartner\resources\views/clients/show.blade.php ENDPATH**/ ?>